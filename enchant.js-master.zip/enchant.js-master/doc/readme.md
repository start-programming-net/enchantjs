Document was removed from repository, please see links below or generate by yourself with `grunt doc` (require install jsdoc-toolkit with `grunt install-jsdoc-toolkit`).

- English
    - <http://wise9.github.com/enchant.js/doc/core/en/index.html>
    - <http://wise9.github.com/enchant.js/doc/plugins/en/index.html> (with plugins)
- Deutsch (German)
    - <http://wise9.github.com/enchant.js/doc/core/de/index.html>
    - <http://wise9.github.com/enchant.js/doc/plugins/de/index.html> (with plugins)
- Japanese
    - <http://wise9.github.com/enchant.js/doc/core/ja/index.html>
    - <http://wise9.github.com/enchant.js/doc/plugins/ja/index.html> (with plugins)
