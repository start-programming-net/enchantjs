## Windows 8 Appliation Template

This is an template project for windows 8 application with enchant.js. Put your enchant.js application in the `App4/enchant` directory, and set size of `<iframe>` tag in `default.html` to the same size of your game. 
