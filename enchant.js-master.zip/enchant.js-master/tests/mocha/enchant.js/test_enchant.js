describe("enchant.js", function(){
    afterEach(function(){
    });

    describe("export", function(){
        it("should export globally", function(){
        });
    });
});